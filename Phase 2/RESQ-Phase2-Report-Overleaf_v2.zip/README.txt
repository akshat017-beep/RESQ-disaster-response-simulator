This bundle is for Overleaf. Upload all files, set the compiler to pdfLaTeX, and compile main.tex.
