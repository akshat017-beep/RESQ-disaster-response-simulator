RESQ Phase-III Presentation — Overleaf

Upload every file in this bundle to one Overleaf project.
Set the main document to main.tex and compile with pdfLaTeX.
Keep graphicera_logo.png and demo1.png beside main.tex.
The presentation contains 18 slides in the uploaded official Phase-III format.
