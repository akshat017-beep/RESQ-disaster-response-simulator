RESQ Phase-III Report — Overleaf

Upload every file in this bundle to one Overleaf project.
Set the main document to main.tex and compile with pdfLaTeX.
Keep geulogo.png and member1.jpg through member4.jpg beside main.tex.
The document follows the uploaded official four-page Phase-III format.
